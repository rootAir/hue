#! /usr/bin/env bash

# This file is auto-generated. DO NOT EDIT.

ALIAS=$1
if [ "${ALIAS}" = "" ]; then
    echo "Alias not provided" >&2
    exit 1
fi

JARDIR=${CMF_SERVER_ROOT:-/usr/share/cmf}/lib/
exec java -cp "${JARDIR}"/security*.jar com.cloudera.enterprise.crypto.JceksPasswordExtractor "/opt/ifrshue/run/creds.localjceks" "${ALIAS}"
